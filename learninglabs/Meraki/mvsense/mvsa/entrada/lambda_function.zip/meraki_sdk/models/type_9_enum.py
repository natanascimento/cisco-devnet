# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class Type9Enum(object):

    """Implementation of the 'Type9' enum.

    The type for the DHCP option. One of: 'text', 'ip', 'hex' or 'integer'

    Attributes:
        TEXT: TODO: type description here.
        IP: TODO: type description here.
        HEX: TODO: type description here.
        INTEGER: TODO: type description here.

    """

    TEXT = 'text'

    IP = 'ip'

    HEX = 'hex'

    INTEGER = 'integer'

