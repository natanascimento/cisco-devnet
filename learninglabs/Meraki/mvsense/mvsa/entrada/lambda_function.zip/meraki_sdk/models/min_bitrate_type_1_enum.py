# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class MinBitrateType1Enum(object):

    """Implementation of the 'MinBitrateType1' enum.

    Minimum bitrate can be set to either 'band' or 'ssid'.

    Attributes:
        BAND: TODO: type description here.
        SSID: TODO: type description here.

    """

    BAND = 'band'

    SSID = 'ssid'

