# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class Type1Enum(object):

    """Implementation of the 'Type1' enum.

    Type of the L7 Rule. Must be 'application', 'applicationCategory', 'host',
    'port' or 'ipRange'

    Attributes:
        APPLICATION: TODO: type description here.
        APPLICATIONCATEGORY: TODO: type description here.
        HOST: TODO: type description here.
        PORT: TODO: type description here.
        IPRANGE: TODO: type description here.

    """

    APPLICATION = 'application'

    APPLICATIONCATEGORY = 'applicationCategory'

    HOST = 'host'

    PORT = 'port'

    IPRANGE = 'ipRange'

