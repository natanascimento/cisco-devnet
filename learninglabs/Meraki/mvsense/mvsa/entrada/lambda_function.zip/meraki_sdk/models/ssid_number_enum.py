# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class SsidNumberEnum(object):

    """Implementation of the 'ssidNumber' enum.

    TODO: type enum description here.

    Attributes:
        ENUM_0: TODO: type description here.
        ENUM_1: TODO: type description here.
        ENUM_2: TODO: type description here.
        ENUM_3: TODO: type description here.
        ENUM_4: TODO: type description here.
        ENUM_5: TODO: type description here.
        ENUM_6: TODO: type description here.
        ENUM_7: TODO: type description here.
        ENUM_8: TODO: type description here.
        ENUM_9: TODO: type description here.
        ENUM_10: TODO: type description here.
        ENUM_11: TODO: type description here.
        ENUM_12: TODO: type description here.
        ENUM_13: TODO: type description here.
        ENUM_14: TODO: type description here.

    """

    ENUM_0 = 0

    ENUM_1 = 1

    ENUM_2 = 2

    ENUM_3 = 3

    ENUM_4 = 4

    ENUM_5 = 5

    ENUM_6 = 6

    ENUM_7 = 7

    ENUM_8 = 8

    ENUM_9 = 9

    ENUM_10 = 10

    ENUM_11 = 11

    ENUM_12 = 12

    ENUM_13 = 13

    ENUM_14 = 14

