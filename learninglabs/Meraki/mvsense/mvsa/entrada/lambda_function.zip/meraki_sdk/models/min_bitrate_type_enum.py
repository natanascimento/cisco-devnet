# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class MinBitrateTypeEnum(object):

    """Implementation of the 'MinBitrateType' enum.

    Minimum bitrate can be set to either 'band' or 'ssid'. Defaults to band.

    Attributes:
        BAND: TODO: type description here.
        SSID: TODO: type description here.

    """

    BAND = 'band'

    SSID = 'ssid'

