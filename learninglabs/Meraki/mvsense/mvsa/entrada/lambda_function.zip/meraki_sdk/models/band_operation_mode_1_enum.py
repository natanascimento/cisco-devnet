# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class BandOperationMode1Enum(object):

    """Implementation of the 'BandOperationMode1' enum.

    Choice between 'dual', '2.4ghz' or '5ghz'.

    Attributes:
        DUAL: TODO: type description here.
        ENUM_24GHZ: TODO: type description here.
        ENUM_5GHZ: TODO: type description here.

    """

    DUAL = 'dual'

    ENUM_24GHZ = '2.4ghz'

    ENUM_5GHZ = '5ghz'

