# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class Settings4Enum(object):

    """Implementation of the 'Settings4' enum.

    How URL categories are applied. Can be 'network default', 'append' or
    'override'.

    Attributes:
        ENUM_NETWORK DEFAULT: TODO: type description here.
        APPEND: TODO: type description here.
        OVERRIDE: TODO: type description here.

    """

    ENUM_NETWORK_DEFAULT = 'network default'

    APPEND = 'append'

    OVERRIDE = 'override'

