# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class Type5Enum(object):

    """Implementation of the 'Type5' enum.

    One of "delete" or "restrict processing"

    Attributes:
        DELETE: TODO: type description here.
        ENUM_RESTRICT PROCESSING: TODO: type description here.

    """

    DELETE = 'delete'

    ENUM_RESTRICT_PROCESSING = 'restrict processing'

