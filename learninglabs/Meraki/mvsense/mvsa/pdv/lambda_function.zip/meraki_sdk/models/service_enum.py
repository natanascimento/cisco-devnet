# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class ServiceEnum(object):

    """Implementation of the 'Service' enum.

    TODO: type enum description here.

    Attributes:
        ENUM_ALL SERVICES: TODO: type description here.
        AIRPLAY: TODO: type description here.
        AFP: TODO: type description here.
        BITTORRENT: TODO: type description here.
        FTP: TODO: type description here.
        ICHAT: TODO: type description here.
        ITUNES: TODO: type description here.
        PRINTERS: TODO: type description here.
        SAMBA: TODO: type description here.
        SCANNERS: TODO: type description here.
        SSH: TODO: type description here.

    """

    ENUM_ALL_SERVICES = 'All Services'

    AIRPLAY = 'AirPlay'

    AFP = 'AFP'

    BITTORRENT = 'BitTorrent'

    FTP = 'FTP'

    ICHAT = 'iChat'

    ITUNES = 'iTunes'

    PRINTERS = 'Printers'

    SAMBA = 'Samba'

    SCANNERS = 'Scanners'

    SSH = 'SSH'

