# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class BandSelectionType1Enum(object):

    """Implementation of the 'BandSelectionType1' enum.

    Band selection can be set to either 'ssid' or 'ap'.

    Attributes:
        SSID: TODO: type description here.
        AP: TODO: type description here.

    """

    SSID = 'ssid'

    AP = 'ap'

