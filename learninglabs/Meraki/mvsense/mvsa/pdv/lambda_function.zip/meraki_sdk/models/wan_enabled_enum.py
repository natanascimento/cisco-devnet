# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class WanEnabledEnum(object):

    """Implementation of the 'WanEnabled' enum.

    Enable or disable the interface (only for MX devices). Valid values are
    'enabled', 'disabled', and 'not configured'.

    Attributes:
        ENABLED: TODO: type description here.
        DISABLED: TODO: type description here.
        ENUM_NOT CONFIGURED: TODO: type description here.

    """

    ENABLED = 'enabled'

    DISABLED = 'disabled'

    ENUM_NOT_CONFIGURED = 'not configured'

