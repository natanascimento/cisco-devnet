# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class ModeEnum(object):

    """Implementation of the 'Mode' enum.

    The site-to-site VPN mode. Can be one of 'none', 'spoke' or 'hub'

    Attributes:
        NONE: TODO: type description here.
        SPOKE: TODO: type description here.
        HUB: TODO: type description here.

    """

    NONE = 'none'

    SPOKE = 'spoke'

    HUB = 'hub'

