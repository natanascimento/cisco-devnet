# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class MajorMinorAssignmentModeEnum(object):

    """Implementation of the 'MajorMinorAssignmentMode' enum.

    The way major and minor number should be assigned to nodes in the network.
    ('Unique', 'Non-unique')

    Attributes:
        UNIQUE: TODO: type description here.
        NONUNIQUE: TODO: type description here.

    """

    UNIQUE = 'Unique'

    NONUNIQUE = 'Non-unique'

