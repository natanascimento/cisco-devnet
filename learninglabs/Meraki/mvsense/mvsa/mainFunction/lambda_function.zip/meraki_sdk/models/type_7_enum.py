# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class Type7Enum(object):

    """Implementation of the 'Type7' enum.

    The signature type for the custom pie chart item. Can be one of 'host',
    'port' or 'ipRange'.

    Attributes:
        HOST: TODO: type description here.
        PORT: TODO: type description here.
        IPRANGE: TODO: type description here.

    """

    HOST = 'host'

    PORT = 'port'

    IPRANGE = 'ipRange'

