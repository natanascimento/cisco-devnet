# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class PolicyEnum(object):

    """Implementation of the 'Policy' enum.

    'allow' or 'deny' traffic specified by this rule

    Attributes:
        ALLOW: TODO: type description here.
        DENY: TODO: type description here.

    """

    ALLOW = 'allow'

    DENY = 'deny'

