# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class ProtocolEnum(object):

    """Implementation of the 'Protocol' enum.

    The type of protocol (must be 'tcp', 'udp', 'icmp' or 'any')

    Attributes:
        TCP: TODO: type description here.
        UDP: TODO: type description here.
        ICMP: TODO: type description here.
        ANY: TODO: type description here.

    """

    TCP = 'tcp'

    UDP = 'udp'

    ICMP = 'icmp'

    ANY = 'any'

