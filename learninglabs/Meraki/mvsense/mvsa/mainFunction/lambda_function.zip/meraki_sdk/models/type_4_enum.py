# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class Type4Enum(object):

    """Implementation of the 'Type4' enum.

    Type of the L7 rule. One of: 'application', 'applicationCategory', 'host',
    'port', 'ipRange'

    Attributes:
        APPLICATION: TODO: type description here.
        APPLICATIONCATEGORY: TODO: type description here.
        HOST: TODO: type description here.
        PORT: TODO: type description here.
        IPRANGE: TODO: type description here.

    """

    APPLICATION = 'application'

    APPLICATIONCATEGORY = 'applicationCategory'

    HOST = 'host'

    PORT = 'port'

    IPRANGE = 'ipRange'

