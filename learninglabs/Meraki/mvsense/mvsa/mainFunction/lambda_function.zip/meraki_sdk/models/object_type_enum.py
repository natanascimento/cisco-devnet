# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class ObjectTypeEnum(object):

    """Implementation of the 'objectType' enum.

    TODO: type enum description here.

    Attributes:
        PERSON: TODO: type description here.
        VEHICLE: TODO: type description here.

    """

    PERSON = 'person'

    VEHICLE = 'vehicle'

