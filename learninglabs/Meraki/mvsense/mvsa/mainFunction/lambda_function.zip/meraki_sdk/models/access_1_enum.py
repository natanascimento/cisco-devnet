# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class Access1Enum(object):

    """Implementation of the 'Access1' enum.

    The type of SNMP access. Can be one of 'none' (disabled), 'community'
    (V1/V2c), or 'users' (V3).

    Attributes:
        NONE: TODO: type description here.
        COMMUNITY: TODO: type description here.
        USERS: TODO: type description here.

    """

    NONE = 'none'

    COMMUNITY = 'community'

    USERS = 'users'

