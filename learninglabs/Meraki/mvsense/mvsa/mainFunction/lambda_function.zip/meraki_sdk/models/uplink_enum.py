# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class UplinkEnum(object):

    """Implementation of the 'uplink' enum.

    TODO: type enum description here.

    Attributes:
        WAN1: TODO: type description here.
        WAN2: TODO: type description here.
        CELLULAR: TODO: type description here.

    """

    WAN1 = 'wan1'

    WAN2 = 'wan2'

    CELLULAR = 'cellular'

