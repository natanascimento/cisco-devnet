# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class Protocol3Enum(object):

    """Implementation of the 'Protocol3' enum.

    The protocol of the incoming packet. Can be one of "ANY", "TCP" or "UDP".
    Default value is "ANY"

    Attributes:
        ANY: TODO: type description here.
        TCP: TODO: type description here.
        UDP: TODO: type description here.

    """

    ANY = 'ANY'

    TCP = 'TCP'

    UDP = 'UDP'

