# -*- coding: utf-8 -*-

"""
    meraki_sdk

    This file was automatically generated for meraki by APIMATIC v2.0 ( https://apimatic.io ).
"""

class V3AuthModeEnum(object):

    """Implementation of the 'V3AuthMode' enum.

    The SNMP version 3 authentication mode. Can be either 'MD5' or 'SHA'.

    Attributes:
        MD5: TODO: type description here.
        SHA: TODO: type description here.

    """

    MD5 = 'MD5'

    SHA = 'SHA'

